
import './App.css'
import Deploy from './Components/Deploy'
import Fuel from './Components/Fuel'
import Navbar from './Components/Navbar'

function App() {
 

  return (
    <>
    <Navbar/>
    <Fuel/>
    <Deploy/>
    </>
  )
}

export default App
